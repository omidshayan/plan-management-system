<?php

define('BASE_PATH', __DIR__);
define('CURRENT_DOMAIN', 'plan-management-system/');
define('DB_HOST', 'localhost');
define('DB_NAME', 'm_ghalib');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
