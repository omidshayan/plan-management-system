# plan-management-system
 This system is designed to manage programs and plans of Ghalib University, which is written in raw PHP backend
