<!DOCTYPE html>
<html>

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="icon" href="https://www.ghalib.edu.af/front_asset/images/logo2.png">
  <link rel="stylesheet" href="../assets/style/style.css" />
  <script src="../assets/js/jquery.js"></script>
  <script src="../assets/js/jquery.form.js"></script>
  <script src="../assets/js/sweetAlert.js"></script>
  <link href="../lib/timePicker/persian-datepicker.min.css" rel="stylesheet" />

  <title>غالب</title>
</head>
<body>
