<script src="../assets/js/FontAwesomeAll.min.js"></script>
<script src="../assets/js/script.js"></script>
<script src="../lib/timePicker/persian-datepicker.min.js"></script>
<script src="../lib/timePicker/persian-date.min.js"></script>
</body>

</html>