<?php include_once 'header.php'; ?>

<div class="report">
    <div class="report-item">
        <div class="report-icon">
            <i class="fas fa-eye"></i>
        </div>
        <div class="report-text">
            <span>تعداد بازدید</span>
        </div>
    </div>

    <div class="report-item">
        <div class="report-icon">
            <i class="fas fa-eye"></i>
        </div>
        <div class="report-text">
            <span>تعداد بازدید</span>
        </div>
    </div>
    <div class="report-item">
        <div class="report-icon">
            <i class="fas fa-eye"></i>
        </div>
        <div class="report-text">
            <span>تعداد بازدید</span>
        </div>
    </div>
</div>
<?php include_once 'footer.php'; ?>